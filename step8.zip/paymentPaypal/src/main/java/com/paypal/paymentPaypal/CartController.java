package com.paypal.paymentPaypal;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

//import org.assertj.core.util.Lists;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.type.CollectionType;
import com.paypal.paymentPaypal.bean.Customer;
import com.paypal.paymentPaypal.bean.Product;
import com.paypal.paymentPaypal.bean.TestProduct;
import com.paypal.paymentPaypal.service.PayPalService;

@Controller
@RequestMapping("/cartpayment")
@SessionAttributes("customerId")
public class CartController {

	@Autowired
	private PayPalService payPalService;

	@RequestMapping(method = RequestMethod.GET)
	public String index(ModelMap modelMap, HttpServletRequest request) throws IOException {
		 
		HttpSession session=request.getSession();
		int customerId=(int) session.getAttribute("userid");
		RestTemplate restTemplate = new RestTemplate();

		ArrayList<Product> cartItems = new ArrayList<Product>(); 
		
		/*
		 * if(modelMap.get("customerId")!=null) customerId = (int)
		 * modelMap.get("customerId"); customerId=1;
		 */
		String restUrl = "http://localhost:8087/hellorest/cartdetails/"+customerId;

		cartItems = restTemplate.getForObject(restUrl, ArrayList.class);
		//Object Conversion
		
		 ObjectMapper mapper = new ObjectMapper();
		 String jsonArray = mapper.writeValueAsString(cartItems);
		 
		    CollectionType javaType = mapper.getTypeFactory()
		      .constructCollectionType(List.class, Product.class);
		    List<Product> asList = mapper.readValue(jsonArray, javaType);
		
		    
		    for (Product c : asList) {
		    	c.setProductPrice(c.getProductPrice()*0.015);		    	
		    	}
		modelMap.put("products", asList);
		modelMap.put("payPalConfig", payPalService.getPayPalConfig());
		return "payment";
	}

	@RequestMapping(value = "/success", method = RequestMethod.GET)
	public String success(HttpServletRequest request,ModelMap modelMap) throws IOException {
		
		int customerId;

		if(modelMap.get("customerId")!=null)
		customerId   = (int) modelMap.get("customerId");
		
        customerId=1;
        
		RestTemplate restTemplate = new RestTemplate();

		ArrayList<Product> cartItems = new ArrayList<Product>(); 
		
		String restUrl = "http://localhost:8087/hellorest/cartdetails/"+customerId;
		String restUrlforCustomer = "http://localhost:8087/hellorest/customerdetails/"+customerId;
		cartItems = restTemplate.getForObject(restUrl, ArrayList.class);
		//Object Conversion
		
		 ObjectMapper mapper = new ObjectMapper();
		 String jsonArray = mapper.writeValueAsString(cartItems);
		 
		    CollectionType javaType = mapper.getTypeFactory()
		      .constructCollectionType(List.class, Product.class);
		    List<Product> asList = mapper.readValue(jsonArray, javaType);
		    
		    for (Product c : asList) {
		    	System.out.println(c.getProductPrice()); 
		    	}
		    Customer customer=restTemplate.getForObject(restUrlforCustomer, Customer.class);
		    System.out.println(customer.getCustomerEmail());
		modelMap.put("products", asList);
		modelMap.put("customer", customer);
				
		return "success";
	}

}
