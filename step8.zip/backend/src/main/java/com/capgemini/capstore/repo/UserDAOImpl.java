package com.capgemini.capstore.repo;


import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.capstore.dto.Admin;
import com.capgemini.capstore.dto.Customer;
import com.capgemini.capstore.dto.Merchant;
import com.capgemini.capstore.dto.User;

@Repository
@Transactional
public class UserDAOImpl implements userDAO {

	@PersistenceContext
	EntityManager entitymanager;
	@Override
	public void createCustomer(Customer user) {
		
		entitymanager.persist(user);
		
	
	}


	@Override
	public void createMerchant(Merchant mer) {
		// TODO Auto-generated method stub
		entitymanager.persist(mer);
		
		
	}



	
	@Override
	public void createUser(User user) {
		// TODO Auto-generated method stub
		entitymanager.persist(user);
		
	}


	@Override
	public User validateUser(User user) {
		// TODO Auto-generated method stub
		
		String email=user.getEmailId();
		String password=user.getPassword();
		Query query=entitymanager.createQuery("Select u from User u where u.emailId=:email");
		query.setParameter("email", email);
		System.out.println("hello \n");
		try {
			if (query.getResultList().size()==1) {
	{
		System.out.println("hello2");
		User u=(User) query.getSingleResult();
		System.out.println("after single result");
			if(u.getPassword().equals(password))
				{
				System.out.println("in equal condition");
				return u;
				}
	}
		}}
		catch(NoResultException e) {
			return null;
		}
	/*	  User result =ls.get(0);
	//	System.out.println(query.getResultList());
		System.out.println(result.getRole());*/
		return null;
		
	}


	@Override
	public Admin getAdminByEmail(String email) {
		// TODO Auto-generated method stub
		email+=".com";
		Query query=entitymanager.createQuery("Select u from Admin u where email=:email");
		query.setParameter("email", email);
		Admin u=(Admin) query.getSingleResult();
		
		return u;
		
	}
public String forgetEmail(String emailid) {
	emailid+=".com";
	Query query=entitymanager.createQuery("Select u from User u where emailid=:emailid");
	query.setParameter("emailid", emailid);
	User user = null;
	try{
		if(query.getSingleResult()!=null)
		{
				 user=(User) query.getSingleResult();
				return user.getPassword();
		}
	}
	catch(Exception e)
	{
		
	}
	return null;
}

	@Override
	public Merchant getMerchantByEmail(String email) {
		// TODO Auto-generated method stub
		email+=".com";
		Query query=entitymanager.createQuery("Select u from Merchant u where email=:email");
		query.setParameter("email", email);
		try
		{
		
		Merchant u=(Merchant) query.getSingleResult();
		return u;
		
		}
		catch(Exception e)
		{
			return null;
		}
	}


	@Override
	public Customer getCustomerByEmail(String email) {
		// TODO Auto-generated method stub
		email+=".com";
		Query query=entitymanager.createQuery("Select u from Customer u where email=:email");
		query.setParameter("email", email);
		System.out.println("Meail 1"+email);
		try
		{
		Customer u=(Customer) query.getSingleResult();
		System.out.println("Meail 2");

		return u;
			
		}
			catch(Exception e)
			{

				return null;
			}
	}


	@Override
	public void changePassword(User user) {
		// TODO Auto-generated method stub
		String email = user.getEmailId();
		String pass = user.getPassword();
		Query query=entitymanager.createQuery("Select u from Customer u where password=:pass");
		query.setParameter("password", pass);
		 query.getSingleResult();
		
		
		
	}


	@Override
	public User getUserByEmail(String emailId) {
		Query query=entitymanager.createQuery("Select u from User u where emailid=:email");
		query.setParameter("email", emailId);
		try {
			System.out.println(emailId);
		User u=(User) query.getSingleResult();
		return u;
		}
		catch (Exception e) {
			System.out.println("User not exist");
			return null;
		}
	}




}
