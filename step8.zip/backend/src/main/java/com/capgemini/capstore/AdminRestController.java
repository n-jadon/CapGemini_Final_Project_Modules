
package com.capgemini.capstore;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.capstore.dto.Customer;
import com.capgemini.capstore.dto.Merchant;
import com.capgemini.capstore.dto.Product;
import com.capgemini.capstore.repo.MerchantRepos;



@RestController
@RequestMapping("rest")
public class AdminRestController {

	@Autowired
	MerchantRepos merchantRef;

	@RequestMapping(method = RequestMethod.GET, value = "/merchantList")
	public List<Merchant> show() {
		System.out.println("in merchant");
		return merchantRef.findAll();

	}

	@RequestMapping(method = RequestMethod.GET, value = "/customerList")
	public List<Customer> showCustomers() {
		System.out.println("in customer");
		return merchantRef.findAllCustomer();

	}

	@RequestMapping(method = RequestMethod.GET, value = "/merchantProfile/{id}")
	public Merchant viewProfile(@PathVariable("id") String id) {
		//
		// System.out.println("in one merchant");
		Merchant m = merchantRef.findOne(Integer.parseInt(id));
		// System.out.println(m);
		return m;
	}

	@RequestMapping(method = RequestMethod.GET, value = "/merchantInventory/{id}")
	public ArrayList<Product> viewMerchantInventory(@PathVariable("id") String id) {
		//
		// System.out.println("in one merchant");
		ArrayList<Product> listOfProducts = new ArrayList<>();
		Merchant m = merchantRef.findOne(Integer.parseInt(id));
System.out.println(m.getMerchantEmail());
		listOfProducts = (ArrayList<Product>) merchantRef.findMerchantProducts(m);
System.out.println(listOfProducts);
		return listOfProducts;
	}

	@RequestMapping(method = RequestMethod.GET, value = "/customerProfile/{id}")
	public Customer viewCustomerProfile(@PathVariable("id") String id) {
		//
		// System.out.println("in one merchant");
		Customer cusRef = merchantRef.findCustomer(Integer.parseInt(id));
		// System.out.println(m);
		return cusRef;
	}
	/*
	 * @RequestMapping(method=RequestMethod.GET,value="/admin/{id}") public Admin
	 * viewAdmin(@PathVariable("id") String id) { // //
	 * System.out.println("in one merchant"); Admin a=
	 * merchantRef.findAdmin(Integer.parseInt(id)); // System.out.println(m); return
	 * a; }
	 */

}
