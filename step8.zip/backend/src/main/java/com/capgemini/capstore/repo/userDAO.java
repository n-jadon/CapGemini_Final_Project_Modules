package com.capgemini.capstore.repo;

import com.capgemini.capstore.dto.Admin;
import com.capgemini.capstore.dto.Customer;
import com.capgemini.capstore.dto.Merchant;
import com.capgemini.capstore.dto.User;

//Follow TODOs (if available)
/**
 * 
 * This is a CarDAO class
 * @see java.lang.Object
 * @author Abhishek
 * 
 *
 */
public interface userDAO 
{
    public void createCustomer(Customer user);
	public void createMerchant(Merchant mer);
	public User validateUser(User user);
	public void createUser(User user);
	public Admin getAdminByEmail(String email);
	public Merchant getMerchantByEmail(String email);
	public Customer getCustomerByEmail(String email);
	public void changePassword(User user);
	public String forgetEmail(String email);
	public User getUserByEmail(String emailId);

}