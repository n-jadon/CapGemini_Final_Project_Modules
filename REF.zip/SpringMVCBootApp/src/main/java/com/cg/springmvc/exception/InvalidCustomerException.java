package com.cg.springmvc.exception;

public class InvalidCustomerException extends RuntimeException{

}
