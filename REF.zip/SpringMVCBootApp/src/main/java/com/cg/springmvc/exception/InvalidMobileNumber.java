package com.cg.springmvc.exception;

public class InvalidMobileNumber extends RuntimeException{

}
