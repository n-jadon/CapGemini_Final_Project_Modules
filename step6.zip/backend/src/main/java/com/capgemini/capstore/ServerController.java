package com.capgemini.capstore;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.capstore.dto.CartDTO;
import com.capgemini.capstore.dto.Customer;
import com.capgemini.capstore.dto.Wishlist;
import com.capgemini.capstore.exceptions.InvalidInputException;
import com.capgemini.capstore.services.CustomerServices;

@RestController
@RequestMapping("api")
public class ServerController {

	@Autowired
	private CustomerServices customerService; 

	@RequestMapping(value= "viewCustomer/{id}")
	public Customer getCustomer(@PathVariable(value="id")String customerId) {
		 Customer customer=null;
		customer = customerService.getCustomer(Integer.parseInt(customerId));
		return customer;
	}
	@RequestMapping(value= "updateCustomer")
	public Customer updateCustomer(@RequestBody Customer customer) {
		 Customer customer1=null;
		customer1 = customerService.updateCustomer(customer);
		return customer1;
	}
	
	@RequestMapping(value= "/wishlist/{id}")
	public List<Wishlist> getWishlist(@PathVariable(value="id")String customerId) {
		 List<Wishlist> wishList=null;
		try {
			wishList = customerService.getAllWishlist(Integer.parseInt(customerId));
		} catch (InvalidInputException e) {
			return wishList;
		}
		System.out.println("returning wishlist");
		return wishList;
	}

	@RequestMapping(value= "/addProductToWishlist")
	public boolean addProductToWishlist(int customerId, int productId) {
		boolean val;
		try {
			 val=customerService.addProductToWishlist(customerId, productId);
		} catch (InvalidInputException e) {
			return false;
		}
		
		return val;
	}

	@RequestMapping(value= "wishlist/removeFromWishList/{id}")
	public void removeProductFromWishlist(@PathVariable(value="id")String itemId) {
		System.out.println("itemId : "+itemId);
		boolean val;
		try {
			customerService.removeProductFromWishlist(Integer.parseInt(itemId));
		} catch (InvalidInputException e) {
			System.out.println("Error");
		}
	}
/*	@RequestMapping(value= "/applyDiscount")
	public double applyDiscount(int productId){
		
		return customerService.applyDiscount(productId);
	}
*/
	
	
	@RequestMapping(value= "/moveToCart/{customerId}/{productId}")
	public void moveToCart(@PathVariable("customerId") String customerId,@PathVariable("productId") String productId) { 
		try {
			System.out.println("sutomer id= "+customerId+"\nproduct id="+productId);
			customerService.addProductToNewCart(Integer.parseInt(customerId), Integer.parseInt(productId));
		}
		catch  (Exception e) {
			e.printStackTrace();
			System.out.println("Error");
		}
	
	@RequestMapping(value= "/addProductToNewCart/{customerId}/{productId}")
	public void addProductToNewCart(@PathVariable("customerId") String customerId,@PathVariable("productId") String productId) { 
		try {
			System.out.println("sutomer id= "+customerId+"\nproduct id="+productId);
			customerService.moveToCart(Integer.parseInt(customerId), Integer.parseInt(productId));
		}
		catch  (Exception e) {
			e.printStackTrace();
			System.out.println("Error");
		}
	}
	
	@RequestMapping(value= "/addProductToWishlist/{customerId}/{productId}")
	public void addProductToWishlist(@PathVariable("customerId") String customerId,@PathVariable("productId") String productId) { 
		try {
			System.out.println("sutomer id= "+customerId+"\nproduct id="+productId);
			customerService.addProductToWishlist(Integer.parseInt(customerId), Integer.parseInt(productId));
		}
		catch  (Exception e) {
			e.printStackTrace();
			System.out.println("Error");
		}
	}
	
	@RequestMapping(value= "/updateCart")
	public CartDTO updateCart(int customerId,int quantity, int productId) {
		CartDTO cart=null;
		try {
			cart = customerService.updateCart(customerId, productId, quantity);
		} catch (Exception e) {
			return cart;
		}
		
		return cart;
	}
	@RequestMapping(value= "/removeFromCart/{id}")
	public void removeFromCart(@PathVariable(value="id")String cartId) {
		
		 customerService.removeProductFromCart(Integer.parseInt(cartId));
	}
	@RequestMapping(method=RequestMethod.GET,value= "/cart/{id}")
	public ArrayList<CartDTO> getCart(@PathVariable(value="id")String customerId){
		ArrayList<CartDTO> cartList = new ArrayList<CartDTO>();
		
		try {
			cartList = (ArrayList<CartDTO>) customerService.getAllProductsFromCart(Integer.parseInt(customerId));
			for(CartDTO c:cartList) {
				System.out.println(c.getProduct().getProductBrand());
			}
		} catch (InvalidInputException e) {
			System.out.println("Error");
			return cartList;
		}
		System.out.println("returning cartList + "+cartList.size());
		return cartList;
	}
	
	@RequestMapping(method=RequestMethod.GET,value= "/cart/modifyPlus/{id}")
	public void ModifyPlus(@PathVariable(value="id")String cartId){
		System.out.println("in Server");
		customerService.modifyQuantity(cartId,1);
	}
	
	@RequestMapping(method=RequestMethod.GET,value= "/cart/modifyMinus/{id}")
	public void ModifyMinus(@PathVariable(value="id")String cartId){
		customerService.modifyQuantity(cartId,-1);
	}
}
