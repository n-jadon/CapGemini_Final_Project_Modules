package com.paypal.paymentPaypal;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.client.RestTemplate;

//import com.capgemini.capstoreClient.beans.CartDTO;
//import com.capgemini.capstoreClient.beans.Wishlist;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.type.CollectionType;
import com.paypal.paymentPaypal.bean.CartDTO;
import com.paypal.paymentPaypal.bean.Wishlist;


@Controller
public class CartClientController {
	
	private static final String MODIFY_QUANTITY_PLUS = "modifyPlus";

	private static final String MODIFY_QUANTITY_MINUS = "modifyMinus";
	private static final String REMOVE = "remove";
	private static final String VIEW_CART = "view_cart";
	private static final String VIEW_WISHLIST = "view_wishlist";
	private static final String ADD_TO_CART = "add_to_cart";
	
	@RequestMapping("cart")
	public String Cart(ModelMap map,@RequestParam(value = "action") String action,
			@RequestParam(value = "id", required = false) String itemId,HttpServletRequest request) throws JsonParseException, JsonMappingException, IOException{

		HttpSession session=request.getSession();
		int customerId=(int) session.getAttribute("userid");
		RestTemplate restTemplate = new RestTemplate();
		
		if(action.equals(MODIFY_QUANTITY_PLUS))
		{
			System.out.println("plus "+itemId);
			restTemplate.getForObject("http://localhost:8087/api/cart/modifyPlus/"+itemId,void.class);
		}
		else if(action.equals(MODIFY_QUANTITY_MINUS))
		{
			System.out.println("minus "+itemId);
			restTemplate.getForObject("http://localhost:8087/api/cart/modifyMinus/"+itemId,void.class);
		}
		else if(action.equals(REMOVE))
		{
			restTemplate.getForObject("http://localhost:8087/api/removeFromCart/"+itemId,void.class);
		}
		 System.out.println("ABCDEFGHIJKL");
		ArrayList<CartDTO> cartlist = restTemplate.getForObject("http://localhost:8087/api/cart/"+customerId,ArrayList.class);
		
		ObjectMapper mapper=new ObjectMapper();
		mapper.addMixIn(Object.class, IgnoreHibernatePropertiesInJackson.class);
		String jsonArray=mapper.writeValueAsString(cartlist);
		
		CollectionType javaType=mapper.getTypeFactory().constructCollectionType(ArrayList.class, CartDTO.class);
		ArrayList<CartDTO> cartItems=mapper.readValue(jsonArray, javaType);
		
		System.out.println(cartItems);
		System.out.println(cartItems.size());
		map.put("cart",cartItems);
		for(CartDTO c:cartItems) {
			System.out.println(c.getProduct().getProductName());
		}
		System.out.println("ABCDEFGHIJKLMNOPQRSTUVWXYZ");
			return "cart";
		}
	@RequestMapping("wishlist")
	public String WishList(ModelMap map,@RequestParam(value = "action") String action,
			@RequestParam(value = "id", required = false) String itemId,HttpServletRequest request) throws JsonParseException, JsonMappingException, IOException{
		HttpSession session=request.getSession();
		int customerId=(int) session.getAttribute("userid");
		System.out.println("ABC");
		RestTemplate restTemplate = new RestTemplate();
		if(action.equals(ADD_TO_CART))
		{
			restTemplate.getForObject("http://localhost:8087/api/wishlist/moveToCart/"+itemId,void.class);
		}
		else if(action.equals(REMOVE))
		{
			System.out.println("itemid : "+itemId);
			restTemplate.getForObject("http://localhost:8087/api/wishlist/removeFromWishList/"+itemId,void.class);
		}
		ArrayList<Wishlist> wishlist = restTemplate.getForObject("http://localhost:8087/api/wishlist/"+customerId,ArrayList.class);
		
		ObjectMapper mapper=new ObjectMapper();
		mapper.addMixIn(Object.class, IgnoreHibernatePropertiesInJackson.class);
		String jsonArray=mapper.writeValueAsString(wishlist);
		
		CollectionType javaType=mapper.getTypeFactory().constructCollectionType(ArrayList.class, Wishlist.class);
		ArrayList<Wishlist> items=mapper.readValue(jsonArray, javaType);
		
//		System.out.println(cartItems);
		System.out.println("Size : "+items.size());
		map.put("wishlist",items);
		return "wishlist";
		}
	@RequestMapping("add_to_cart/{id}")
	public String addToCart(ModelMap map,@PathVariable(value = "id") String productId,HttpServletRequest request) {
		System.out.println("in clent cart");
		HttpSession session=request.getSession();
		int customerId=(int) session.getAttribute("userid");
		RestTemplate restTemplate = new RestTemplate();
		restTemplate.getForObject("http://localhost:8087/api/addProductToNewCart/"+customerId+"/"+productId, void.class);
		System.out.println("22222");
		ArrayList response = restTemplate.getForObject("http://localhost:8087/capstore",ArrayList.class);
		map.addAttribute("product",response);
		return "customer-homepage";
	}
	@RequestMapping("add_to_wishlist/{id}")
	public String addToWishList(ModelMap map,@PathVariable(value = "id") String productId,HttpServletRequest request) {
		System.out.println("in clent cart");
		HttpSession session=request.getSession();
		int customerId=(int) session.getAttribute("userid");
		RestTemplate restTemplate = new RestTemplate();
		restTemplate.getForObject("http://localhost:8087/api/addProductToWishlist/"+customerId+"/"+productId, void.class);
		System.out.println("22222");
		ArrayList response = restTemplate.getForObject("http://localhost:8087/capstore",ArrayList.class);
		map.addAttribute("product",response);
		return "customer-homepage";
	}
}

@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
abstract class IgnoreHibernatePropertiesInJackson{ }
