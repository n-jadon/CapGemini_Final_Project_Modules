package com.paypal.paymentPaypal.setup;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLDecoder;

import javax.servlet.http.HttpServletRequest;


public class PayPalSucess {

	
	public PayPalResult getPayPal(HttpServletRequest request,PayPalConfig payPalConfig)
	{
	PayPalResult payPalResult = new PayPalResult();
	String[] temp=null;
	String res="";
	try {
		String transId=request.getParameter("tx");
		String authToken=payPalConfig.getAuthToken();
		String query="cmd=_notify-synch&tx="+ transId + "&at="+authToken;
		String url=payPalConfig.getPosturl();
		URL u=new URL(url);
		HttpURLConnection req=(HttpURLConnection)u.openConnection();
		req.setRequestMethod("POST");
		req.setDoOutput(true);
		req.setDoInput(true);
		req.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
		req.setFixedLengthStreamingMode(query.length());
		
		OutputStream outputStream=(OutputStream) req.getOutputStream();
		outputStream.write(query.getBytes());
		outputStream.close();
		
		BufferedReader in= new BufferedReader(new InputStreamReader(req.getInputStream()));
		res=in.readLine();
		System.out.println(in.readLine());
		System.out.println(in.readLine());
		System.out.println("result="+ res);
		if(res.equals("SUCCESS"))
		{
			while((res=in.readLine())!=null) {
				temp=res.split("=");
				if(temp.length==1)
				continue;
				temp[1]=URLDecoder.decode(temp[1], "UTF-8");
				if(temp[0].equals("mc_gross")) {
					payPalResult.setMc_gross(temp[1]);
				}
				if(temp[0].equals("protection_eligibility")) {
					payPalResult.setProtection_eligibility(temp[1]);
				}
				if(temp[0].equals("address_status")) {
					payPalResult.setAddress_status(temp[1]);
				}
				if(temp[0].equals("tax")) {
					payPalResult.setTax(temp[1]);
				}
				if(temp[0].equals("payer_id")) {
					payPalResult.setPayer_id(temp[1]);
				}
				if(temp[0].equals("address_street")) {
					payPalResult.setAddress_street(temp[1]);
				}
				if(temp[0].equals("payment_date")) {
					payPalResult.setPayment_date(temp[1]);
				}
				if(temp[0].equals("payment_status")) {
					payPalResult.setPayment_status(temp[1]);
				}
				
				if(temp[0].equals("charset")) {
					payPalResult.setCharset(temp[1]);
				}
				
				if(temp[0].equals("address_zip")) {
					payPalResult.setAddress_zip(temp[1]);
				}
				
				if(temp[0].equals("last_name")) {
					payPalResult.setLast_name(temp[1]);
				}
				if(temp[0].equals("first_name")) {
					payPalResult.setFirst_name(temp[1]);
				}
			  System.out.println(temp[0]);
			  System.out.println(temp[1]);
			}
			in.close();
		}
		}catch(Exception e){
			System.out.println(e.getMessage());
			payPalResult=null;
		}
	return payPalResult;
			}
			
		}
