package com.paypal.paymentPaypal;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;

@Controller
public class OrderPlacedController {

	@RequestMapping("/myorders")
	String placeorder(ModelMap map,HttpServletRequest request) {
		HttpSession session=request.getSession();
		int userId=(int) session.getAttribute("userid");
		System.out.println("IN CLIENT place order");
		RestTemplate restTemplate = new RestTemplate(); 
		ArrayList response = restTemplate.getForObject("http://localhost:8087/myorders/"+userId,ArrayList.class);
		map.addAttribute("product",response);
		System.out.println("IN CLIENT place order:"+response);
		return "myorders";
	}
	
}
