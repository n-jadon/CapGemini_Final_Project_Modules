package com.paypal.paymentPaypal;

import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.type.CollectionType;
import com.paypal.paymentPaypal.bean.Offer;
import com.paypal.paymentPaypal.bean.Promo;

@Controller
@RequestMapping("couponController")
public class WelcomeController2 {

	// inject via application.properties
	/*
	 * @Value("${welcome.message:test}") private String message = "Hello World";
	 * 
	 * @RequestMapping("/") public String welcome(Map<String, Object> model) {
	 * model.put("message", this.message); return "welcome"; }
	 */

	
	
	
		@RequestMapping("/demo")
		public String form1()
		{return"coupon1";
		}
	
		@RequestMapping(value="form",method = RequestMethod.POST)
		public String GenerateCoupon( 
				@RequestParam("name") String code,@RequestParam("date") String date,@RequestParam("discount")double discount) {
			DateFormat format = new SimpleDateFormat("YYYY-MM-DD",Locale.ENGLISH);
			Date d = null;
			try {
				d = format.parse(date);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			RestTemplate restTemplate = new RestTemplate(); 
			Promo response=new Promo();
             
			
			 response.setDiscountOffered(discount);
			 response.setPromoCode(code);
			 response.setPromoValidity(d);
			 restTemplate.postForObject("http://localhost:8087/api/v1/response",response,Promo.class);
				
			return "generate";
			
	}
		@RequestMapping(value="/Promo",method = RequestMethod.GET)
		public String promo(ModelMap map) throws IOException
		
		{RestTemplate restTemplate = new RestTemplate(); 
			List<Offer> list = new ArrayList<Offer>();
			List<Offer> list2 = new ArrayList<Offer>();
		 list = restTemplate.getForObject("http://localhost:8087/api/v1/response1",List.class,Offer.class);
           // map.addAttribute("list", list);
		if(list.size()>0) {
		 ObjectMapper mapper=new ObjectMapper();
		 String jsonArray=mapper.writeValueAsString(list);
		 CollectionType javaType=mapper.getTypeFactory().constructCollectionType(List.class, Offer.class);
		 list2=mapper.readValue(jsonArray, javaType);
		 System.out.println(list2.get(0).getOfferEndDate());
			map.addAttribute("list", list2);}
		map.addAttribute("list", list);
			
	    return "promo";}
		
		
		
		
		
		
		
		
		
		
		
		
		
}
