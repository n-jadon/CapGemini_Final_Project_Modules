
  package com.paypal.paymentPaypal;
  
  import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.type.CollectionType;
import com.paypal.paymentPaypal.bean.Customer;
import com.paypal.paymentPaypal.bean.Merchant;
import com.paypal.paymentPaypal.bean.MerchantFeedback;
import com.paypal.paymentPaypal.bean.Product;
import com.paypal.paymentPaypal.bean.ProductFeedback;

//import com.capstore.dto.MerchantDto;
    
  @Controller
  @RequestMapping("controller")
  //@SessionAttribute("merchantId")
  public class AdminController {
  
	  
  @RequestMapping(method=RequestMethod.GET,value="merchantdetails") 
  public String merchant(ModelMap modelMap) {
	  RestTemplate restTemplate = new RestTemplate();
	  List<Merchant> response = new ArrayList<Merchant>();
     response = restTemplate.getForObject("http://localhost:8087/rest/merchantList",ArrayList.class);
     modelMap.addAttribute("merchantList",response);
	  return "merchantDetails";
  } 
  
  
  
  @RequestMapping(method=RequestMethod.GET,value="customerdetails") 
  public String customer(ModelMap modelMap) {
	  RestTemplate restTemplate = new RestTemplate();
	  List<Customer> response = new ArrayList<Customer>();
     response = restTemplate.getForObject("http://localhost:8087/rest/customerList", List.class);
     modelMap.addAttribute("customerList",response);
	  return "customerDetails";
  } 
 
  
  @RequestMapping(method=RequestMethod.GET,value="/merchantindex") 
  public String merchantIndex(ModelMap modelMap,HttpSession session) {
	  
	  int merchantId=(int) session.getAttribute("userid");
//	  int merchantId=1;
	  modelMap.put("merchantId",merchantId);
	return "MerchantIndex";
	  
  }
  @RequestMapping(method=RequestMethod.GET,value="/merchantprofile") 
  public String viewProfile(/*@PathVariable("id") String id,*/ ModelMap modelMap,HttpSession session) {
	 
	  int mercId=(int) session.getAttribute("userid");
//	  int mercId=1;
	  RestTemplate restTemplate = new RestTemplate();
	  Merchant merchant= new Merchant();
	 merchant = restTemplate.getForObject("http://localhost:8087/rest/merchantProfile/"+mercId,Merchant.class);
	 
	  modelMap.addAttribute("merchant", merchant);
	return "merchant-profile";
	
  
  }
  
  @RequestMapping(method=RequestMethod.GET,value="/viewinventory") 
  public String merchantInventory(ModelMap modelMap,HttpSession session) throws IOException {
	  
	 int mercId=(int) session.getAttribute("userid");
//	 int mercId=1;
	  RestTemplate restTemplate = new RestTemplate();
	  ArrayList<Product> productList=new ArrayList<Product>();
	 //Product pro= new Product();
	 productList = restTemplate.getForObject("http://localhost:8087/rest/merchantInventory/"+mercId,ArrayList.class);
	 //System.out.println(productList.get(0).getProductBrand());
	
	 ObjectMapper mapper=new ObjectMapper();
	 String json=mapper.writeValueAsString(productList);
	 CollectionType javaType=mapper.getTypeFactory().constructCollectionType(List.class, Product.class);
	 List<Product> productList1=mapper.readValue(json, javaType);
	 
	 
	 modelMap.addAttribute("merchantProducts", productList1);
	return "viewinventory";
	  
  }
  
  @RequestMapping(method=RequestMethod.GET,value="/viewProductsOfParticularMerchant/{id}") 
  public String viewProductsOfParticularMerchant(@PathVariable("id")int id,ModelMap modelMap) throws IOException {
	  
	  RestTemplate restTemplate = new RestTemplate();
	  ArrayList<Product> productList=new ArrayList<Product>();
	 //Product pro= new Product();
	 productList = restTemplate.getForObject("http://localhost:8087/rest/merchantInventory/"+id,ArrayList.class);
	 //System.out.println(productList.get(0).getProductBrand());
	
	 ObjectMapper mapper=new ObjectMapper();
	 String json=mapper.writeValueAsString(productList);
	 CollectionType javaType=mapper.getTypeFactory().constructCollectionType(List.class, Product.class);
	 List<Product> productList1=mapper.readValue(json, javaType);
	 
	 
	 modelMap.addAttribute("merchantProducts", productList1);
	return "viewinventory";
	  
  }
  
  
  
	/*
	 * @RequestMapping(method=RequestMethod.GET,value="/manageinventory") public
	 * String manageInventory(ModelMap modelMap,HttpSession session) { //Merchant
	 * merchantp=(Merchant) session.getAttribute("merchantId");
	 * 
	 * return "Manage-Inventory";
	 * 
	 * }
	 */
  
  
	/*
	 * @RequestMapping(method=RequestMethod.GET,value="/customerindex") public
	 * String customerIndex(ModelMap modelMap,HttpSession session) { //Merchant
	 * merchantp=(Merchant) session.getAttribute("merchantId");
	 * modelMap.put("customerId","1001"); return "CustomerIndex";
	 * 
	 * }
	 * 
	 * @RequestMapping(method=RequestMethod.GET,value="/customerprofile/{id}")
	 * public String viewCustomerProfile(@PathVariable("id") String id, ModelMap
	 * modelMap) { RestTemplate restTemplate = new RestTemplate(); Customer
	 * customer= new Customer(); customer =
	 * restTemplate.getForObject("http://localhost:8087/rest/customerProfile/"+id,
	 * Customer.class);
	 * 
	 * modelMap.addAttribute("customer", customer); return "Customerprofile";
	 * 
	 * 
	 * }
	 * 
	 * @RequestMapping(method=RequestMethod.GET,value="/customer/edit") public
	 * String editCustomer(ModelMap modelMap) { return "CustomerEditProfile"; }
	 * 
	 */
  
  
  
  //////////////////////////////
  
  
  @RequestMapping(method = RequestMethod.GET, value = "admin")
	public String index(ModelMap modelMap) {
	  //modelMap.put("admin", modelMap);
		return "admin";
	}

	/*@RequestMapping(method = RequestMethod.GET, value = "/merchantdetails")
	public String merchant(ModelMap modelMap) {
		RestTemplate restTemplate = new RestTemplate();
		List<Merchant> response = new ArrayList<Merchant>();
		response = restTemplate.getForObject("http://localhost:8087/restController/merchantList", List.class);
		System.out.println("here");
		System.out.println(response);
		modelMap.put("merchantList", response);
		
		return "merchantDetails";
	}*/
	

	@RequestMapping(method = RequestMethod.GET, value = "/productdetails/{id}")
	public String product(ModelMap modelMap,@PathVariable("id")int id) {
		
		RestTemplate restTemplate = new RestTemplate();
		List<Product> response = new ArrayList<Product>();
		System.out.println(id+" id");
		response = restTemplate.getForObject("http://localhost:8087/restController/productList/"+id, List.class);
		System.out.println("here");
		System.out.println(response);
		modelMap.put("productList", response);
		modelMap.put("merchantId",id);
		return "productDetails";
	}


	
	//delete merchant
	@RequestMapping(method = RequestMethod.POST, value = "/deleteMerchants")
	public String Merchant(@RequestParam("id") String ids,ModelMap modelMap) {
		RestTemplate restTemplate = new RestTemplate();
		System.out.println("hello Admin");
		//for(String id:ids) {
			System.out.println(ids);
		//}
		System.out.println("Pushkal");
		restTemplate.postForObject("http://localhost:8087/restController/delete?id="+ids, ids, String[].class);
		List<Merchant> response = new ArrayList<Merchant>();
		response = restTemplate.getForObject("http://localhost:8087/restController/merchantList", List.class);
		System.out.println("here");
		System.out.println(response);
		modelMap.put("merchantList", response);

		//modelMap.put("customerList", response);
		return "merchantDetails";
	}
	
	

	@RequestMapping(method = RequestMethod.POST, value = "/deleteProduct")
	public String Product(@RequestParam("id") String ids,ModelMap modelMap,HttpServletRequest request) {
		RestTemplate restTemplate = new RestTemplate();
		System.out.println("hello Admin");
		//for(String id:ids) {
			System.out.println(ids);
		//}
			HttpSession session=request.getSession();
			 int merchantId=(int) session.getAttribute("userid");
			
//			int merchantId=1;
		System.out.println("Pushkal");
		restTemplate.postForObject("http://localhost:8087/restController/deleteProduct?id="+ids, ids, String[].class);
		//modelMap.put("customerList", response);
		List<Product> response = new ArrayList<Product>();
		response = restTemplate.getForObject("http://localhost:8087/restController/productList/"+merchantId, List.class);
		System.out.println("here");
		System.out.println(response);
		modelMap.put("productList", response);

		return "productDetails";
	}
	
	/*for adding merchant into database*/

	@RequestMapping(method = RequestMethod.GET, value = "/merchant")
	public String addNewMerchant(@ModelAttribute("merchant") Merchant merchant, ModelMap modelMap) {
		return "registerMerchant1";
	}
	@RequestMapping(method=RequestMethod.POST,value="/addMerchant")
	public String list1(@ModelAttribute("merchant") Merchant merchant,ModelMap modelMap){
		RestTemplate restTemplate = new RestTemplate();
		System.out.println("Inside AdminController"+ merchant.getMerchantId());
		restTemplate.postForObject("http://localhost:8087/restController/addMerchant", merchant, Merchant.class);
		System.out.println(merchant.getMerchantName());
		List<Merchant> response = new ArrayList<Merchant>();
		
		response = restTemplate.getForObject("http://localhost:8087/restController/merchantList", List.class);
		System.out.println("here");
		System.out.println(response);
		modelMap.put("merchantList", response);


/*		RestTemplate restTemplatereceive = new RestTemplate();
		List<Merchant> response = new ArrayList<Merchant>();
		response = restTemplatereceive.getForObject("http://localhost:8087/rest/merchantList", List.class);
*/		//modelMap.put("merchantList", response);
		return "merchantDetails";

	
	}
	
	
	/*For adding product in the database*/
	
	@RequestMapping(method=RequestMethod.GET, value="/Product")
	public String product(@ModelAttribute("product") Product product, ModelMap map){
		return "addProduct1";
		
	}
	
	@RequestMapping(method=RequestMethod.POST,value="/addProduct")
	public String addNewProduct(@ModelAttribute("product") Product product,ModelMap map,HttpServletRequest request){
	/*	Merchant merchant=new Merchant(1);
		product.setMerchant(merchant);*/
		System.out.println("hello world");
		RestTemplate restTemplate = new RestTemplate();
		HttpSession session=request.getSession();
		int merchantId=(int) session.getAttribute("userId");
//		int merchantId=1;
		restTemplate.postForObject("http://localhost:8087/restController/addProd?id="+merchantId, product, Product.class);
		System.out.println("ghghgh");
		System.out.println(product.getProductModel());
		List<Product> response = new ArrayList<Product>();
		response = restTemplate.getForObject("http://localhost:8087/restController/productList/"+merchantId, List.class);
		System.out.println("here");
		System.out.println(response);
		map.put("productList", response);

		return "productDetails";
	

	}

	@RequestMapping(method=RequestMethod.GET, value="/Feedback")
	public String product(@ModelAttribute("proFeedback") ProductFeedback proFeedback, ModelMap map){
		System.out.println("Inside /Feedback");
		return "productFeedbackTest";
		
	}
	
	@RequestMapping(method=RequestMethod.POST,value="/addFeedback")
	public String addNewProductFeedback(@ModelAttribute("proFeedback") ProductFeedback proFeedback,ModelMap modelMap){
	/*	Merchant merchant=new Merchant(1);
		product.setMerchant(merchant);*/
		System.out.println("hello world");
		//PRODUCT ID TO BE RECEIVED FROM SESSION
		proFeedback.setRating(4);
		int prod_id=proFeedback.getProduct().getProductId();
		RestTemplate restTemplate = new RestTemplate();
		
		restTemplate.postForObject("http://localhost:8087/restController/addProductFeedback?id="+prod_id, proFeedback, ProductFeedback.class);
		System.out.println("ghghgh");
		//System.out.println(proFeedback.get);
		//TO CALL THE DISPLAY PAGE THAT FETCH THE VALUES
		return "productFeedbackTest";
	

	}
	
	
	@RequestMapping(method=RequestMethod.GET, value="/MerchantFeedback")
	public String Merchantproduct(@ModelAttribute("merchantFeedback") MerchantFeedback merchantFeedback, ModelMap map){
		System.out.println("Inside /MerchantFeedback");
		return "merchantFeedbackTest";
		
	}
	
	@RequestMapping(method=RequestMethod.POST,value="/addMerchantFeedback")
	public String addNewMerchantFeedback(@ModelAttribute("merchantFeedback") MerchantFeedback merchantFeedback, ModelMap map){
	/*	Merchant merchant=new Merchant(1);mer
		product.setMerchant(merchant);*/
		System.out.println("hello world");
		//PRODUCT ID TO BE RECEIVED FROM SESSION
		merchantFeedback.setRating(4);
		int prod_id=merchantFeedback.getMerchant().getMerchantId();
		RestTemplate restTemplate = new RestTemplate();
		
		restTemplate.postForObject("http://localhost:8087/restController/addMerchantFeedback?id="+prod_id, merchantFeedback, MerchantFeedback.class);
		System.out.println("ghghgh");
		
		//TO CALL THE DISPLAY PAGE THAT FETCH THE VALUES
		return "productFeedbackTest";
	

	}


	@ModelAttribute("merchant")
	public Merchant createMerchant() {
		return new Merchant();
	}
	@ModelAttribute("product")
	public Product createProduct() {
		return new Product();
	}
	
	
	@ModelAttribute("proFeedback")
	public ProductFeedback createFeedback() {
		return new ProductFeedback();
	}

  
  
  
  
  
  
  
  
  
  
  }
 
