package com.vim.dao.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.dto.CarDTO;
import com.vim.dao.CarDAO;

@Repository
@Transactional
public class JPACarDAO implements CarDAO{
	
    @PersistenceContext
	private EntityManager  entityManager;
   
    public JPACarDAO() {
    	System.out.println("JPACarDAO instantiated...");
    }
    
	@Override
	@Transactional
	public void create(CarDTO car) {
	
		try {
			System.out.println(car.getModel());
					entityManager.persist(car);
						entityManager.close();
		} catch (RuntimeException e) {
			throw e;
		} finally {
			entityManager.close();
		}
	}
	
	@Override
	public void delete(String[] ids) {
		
	
		try {
				for(String sID : ids){
				CarDTO car = entityManager.find(CarDTO.class, Integer.parseInt(sID));
				entityManager.remove(car);
			}
		} catch (RuntimeException e) {
		
		throw e;
		} finally {
		entityManager.close();
		}		
	}
	
	@Override
	public List<CarDTO> findAll() {
		
		try {
			Query query = entityManager.createQuery(
			"select car from CarDTO car");
	
			List<CarDTO> ls=(List<CarDTO>)query.getResultList();
			return ls;
		} finally {
		entityManager.close();
		}
	}
	
	@Override
	public CarDTO findById(int id) {
	
		CarDTO car = entityManager.find(CarDTO.class, id);
		return car;
	}
	
	@Override
	public void update(CarDTO car) {
		
	
		try {
			
			entityManager.merge(car);			
		} catch (RuntimeException e) {
			
			throw e;
		} finally {
			entityManager.close();
		}
	}
	@Override
	public CarDTO findByModelYear(String modelYear) {
		Query query = entityManager.createQuery("select car from CarDTO car");
		List<CarDTO> ls=(List<CarDTO>)query.getResultList();
		CarDTO car = null;
		for(CarDTO c:ls)
		{
			if(c.getModelYear().equals(modelYear))
				car=c;
		}
		return car;
	}
	/*@Override
	public CarDTO findByMake(String make) {
		Query query = (Query) entityManager.createQuery("select car from CarDTO car where make = :make",CarDTO.class).setParameter("make", make);
		CarDTO car = (CarDTO) query.getSingleResult();;
		return car;
	}*/
}
