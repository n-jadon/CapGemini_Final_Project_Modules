package com.capgemini.service;

import java.util.List;

import com.capgemini.dto.Product;

public class CartServiceImpl implements CartService{

	public List<Product> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	public void update(Product car) {
		// TODO Auto-generated method stub
		
	}

	public double getTotalCost() {
		// TODO Auto-generated method stub
		return 0;
	}

	public double getDiscount() {
		// TODO Auto-generated method stub
		return 0;
	}

	public double getNetPrice() {
		// TODO Auto-generated method stub
		return 0;
	}

}
