package com.capgemini.service;

public interface CartService extends WishListService{
	double getTotalCost();
	double getDiscount();
	double getNetPrice();
}
