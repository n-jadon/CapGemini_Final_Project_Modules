package com.capgemini.service;

import java.util.List;

import com.capgemini.dto.Product;

public interface WishListService {
	public List<Product> findAll();
	public void update(Product car);
}
