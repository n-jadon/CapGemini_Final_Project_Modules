package com.capgemini.dao;


public interface CartDAO extends WishListDAO{
	double getTotalCost();
	double getDiscount();
	double getNetPrice();
}
