package com.capgemini.dao;

import java.util.List;

import com.capgemini.dto.Product;

public interface WishListDAO {
	public List<Product> findAll();
	public void update(Product car);
}
