package com.capgemini.dao;

import java.util.List;

import com.capgemini.dto.Product;

public class WishListDAOImpl implements WishListDAO{

	public List<Product> findAll() {
		return null;
	}

	public void update(Product car) {
		
	}

}
