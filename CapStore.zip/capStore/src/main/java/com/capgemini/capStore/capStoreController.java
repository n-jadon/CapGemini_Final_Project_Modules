package com.capgemini.capStore;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.dto.Product;
import com.capgemini.service.CartService;

@RestController
@RequestMapping("/capStore")
public class capStoreController {
	
	@Autowired
	CartService service;
	
	@RequestMapping(value="/cart",method=RequestMethod.GET )
	public String CartfindAll(@ModelAttribute("product") Product product, ModelMap map)
	{
		String destinationPage = "";
		List<Product> productList = new ArrayList<Product>();
		productList = service.findAll();
		map.addAttribute("productList", productList);
		map.addAttribute("totalPrice", service.getTotalCost());
		map.addAttribute("discount", service.getDiscount());
		map.addAttribute("netPrice",service.getNetPrice());
		return destinationPage = "Cart";	
	}
	@RequestMapping(value="/wishlist",method=RequestMethod.GET )
	public String wishListfindAll(@ModelAttribute("product") Product product, ModelMap map)
	{
		String destinationPage = "";
		List<Product> productList = new ArrayList<Product>();
		productList = service.findAll();
		map.addAttribute("productList", productList);
		return destinationPage = "WishList";	
	}
	@RequestMapping(value="/applyCoupan",method=RequestMethod.GET )
	public String applyCoupan(@ModelAttribute("product") Product product, ModelMap map)
	{
		String destinationPage = "";
		List<Product> productList = new ArrayList<Product>();
		productList = service.findAll();
		map.addAttribute("productList", productList);
		map.addAttribute("totalPrice", service.getTotalCost());
		map.addAttribute("discount", service.getDiscount());
		map.addAttribute("netPrice",service.getNetPrice());
		return destinationPage = "Cart";	
	}
}
