package com.capgemini.capStore;

public class capStoreController {

}
