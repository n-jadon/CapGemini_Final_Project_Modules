package com.capgemini.capstore.services;

import java.util.List;

import com.capgemini.capstore.dto.Product;




public interface IProductService {

	public List<Product> getProduct();
	public List<Product> sortPriceLowToHigh();
	public List<Product> sortPriceHighToLow();
	public List<Product> getSearch(String search);
	public List<Product> single(int idd);
}
