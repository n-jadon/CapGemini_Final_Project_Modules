package com.capgemini.capstore.repo;

import java.util.List;

import com.capgemini.capstore.dto.CartDTO;




public interface IOrderPlacedRepository {
	public List<CartDTO> getOrderPlacedProduct();

}
